package com.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SlotDao {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/sportsystem", "root", "admin");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public static List<String> getAllFacilityNames() {
        List<String> facilities = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT DISTINCT name FROM facility");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                facilities.add(rs.getString("name"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return facilities;
    }

    public static int getFacilityIdByName(String facilityName) {
        int facilityId = -1;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT facilityId FROM facility WHERE name = ?");
            ps.setString(1, facilityName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                facilityId = rs.getInt("facilityId");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return facilityId;
    }

    public static List<String> getDatesByFacilityId(int facilityId) {
        List<String> dates = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT DISTINCT date FROM slot WHERE facilityId = ?");
            ps.setInt(1, facilityId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                dates.add(rs.getString("date"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dates;
    }
}
