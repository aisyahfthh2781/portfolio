/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.Model.bookingStudent;
import java.sql.*;
import java.util.*;
public class bookingDao {
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sportsystem", "root", "admin");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
    
public static int save(bookingStudent e) {
    int status = 0;
    try {
        Connection con = bookingDao.getConnection();
        PreparedStatement ps = con.prepareStatement("INSERT INTO bookingstudent(facility, date, time, purpose, category) VALUES (?, STR_TO_DATE(?, '%Y-%m-%d'), ?, ?, ?)");
        
        ps.setString(1, e.getFacility());
        ps.setString(2, e.getDate());
        ps.setString(3, e.getTime());
        ps.setString(4, e.getPurpose());
        ps.setString(5, e.getCategory());

        status = ps.executeUpdate();

        con.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }

    return status;
}

    
public static int update(bookingStudent e) {
    int status = 0;
    try {
        Connection con = bookingDao.getConnection();
        PreparedStatement ps = con.prepareStatement("UPDATE bookingstudent SET facility=?, date=STR_TO_DATE(?, '%Y-%m-%d'), time=?, purpose=?, category=? WHERE bookingId=?");

        ps.setString(1, e.getFacility());
        ps.setString(2, e.getDate());
        ps.setString(3, e.getTime());
        ps.setString(4, e.getPurpose());
        ps.setString(5, e.getCategory());
        ps.setInt(6, e.getBookingId());

        status = ps.executeUpdate();

        con.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return status;
}

     
     public static int delete(int bookingId) {
        int status = 0;
        try {
            Connection con = bookingDao.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from bookingstudent where bookingId=?");
            ps.setInt(1, bookingId);
            status = ps.executeUpdate();

            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return status;
    }
     
     public static bookingStudent getUserById(int bookingId) {
        bookingStudent e = new bookingStudent();

        try {
            Connection con = bookingDao.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from bookingstudent where bookingId=?");

            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                e.setBookingId(rs.getInt(1));
                e.setFacility(rs.getString(2));
                e.setDate(rs.getString(3));
                e.setTime(rs.getString(4));
                e.setPurpose(rs.getString(5));
                e.setCategory(rs.getString(6));
            }
            con.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

    public static List<bookingStudent> getAllUsers() {
        List<bookingStudent> list = new ArrayList<bookingStudent>();

        try {
            Connection con = bookingDao.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from bookingstudent");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                bookingStudent e = new bookingStudent();
                e.setBookingId(rs.getInt(1));
                e.setFacility(rs.getString(2));
                e.setDate(rs.getString(3));
                e.setTime(rs.getString(4));
                e.setPurpose(rs.getString(5));
                e.setCategory(rs.getString(6));
                list.add(e);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
