package com.WEB;

import com.Model.facility;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class facilityDAO {

    private String jdbcURL = "jdbc:mysql://localhost/sportsystem";
    private String jdbcUsername = "root";
    private String jdbcPassword = "admin";

    private static final String SELECT_FACILITIES_BY_TYPE = "SELECT * FROM facility WHERE type = ?";
    private static final String INSERT_FACILITY_SQL = "INSERT INTO facility (name, type, capacity, slot, status) VALUES (?, ?, ?, ?, ?)";

    public static Connection getConnection() {
         Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/sportsystem", "root", "admin");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public List<facility> getFacilitiesByType(String type) {
        List<facility> facilities = new ArrayList<>();
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FACILITIES_BY_TYPE);) {
            preparedStatement.setString(1, type);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("facilityId");
                String name = rs.getString("name");
                String facilityType = rs.getString("type");
                int capacity = rs.getInt("capacity");
                int slot = rs.getInt("slot");
                String status = rs.getString("status");
                facilities.add(new facility(id, name, facilityType, capacity, slot, status));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return facilities;
    }
    
    public List<facility> getAllFacilities() {
    List<facility> facilities = new ArrayList<>();
    String SELECT_ALL_FACILITIES = "SELECT * FROM facility";
    try (Connection connection = getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_FACILITIES);) {
        ResultSet rs = preparedStatement.executeQuery();

        while (rs.next()) {
            int id = rs.getInt("facilityId");
            String name = rs.getString("name");
            String type = rs.getString("type");
            int capacity = rs.getInt("capacity");
            int slot = rs.getInt("slot");
            String status = rs.getString("status");
            facilities.add(new facility(id, name, type, capacity, slot, status));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return facilities;
}

    public void addFacility(facility facility) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FACILITY_SQL)) {
            preparedStatement.setString(1, facility.getName());
            preparedStatement.setString(2, facility.getType());
            preparedStatement.setInt(3, facility.getCapacity());
            preparedStatement.setInt(4, facility.getSlot());
            preparedStatement.setString(5, facility.getStatus());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to update facility
    public void updateFacility(facility facility) {
        String UPDATE_FACILITY_SQL = "UPDATE facility SET name = ?, type = ?, capacity = ?, slot = ?, status = ? WHERE facilityId = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_FACILITY_SQL)) {
            preparedStatement.setString(1, facility.getName());
            preparedStatement.setString(2, facility.getType());
            preparedStatement.setInt(3, facility.getCapacity());
            preparedStatement.setInt(4, facility.getSlot());
            preparedStatement.setString(5, facility.getStatus());
            preparedStatement.setInt(6, facility.getFacilityId());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to get facility by ID
    public facility getFacilityById(int facilityId) {
        facility facility = null;
        String SELECT_FACILITY_BY_ID = "SELECT * FROM facility WHERE facilityId = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FACILITY_BY_ID)) {
            preparedStatement.setInt(1, facilityId);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String type = rs.getString("type");
                int capacity = rs.getInt("capacity");
                int slot = rs.getInt("slot");
                String status = rs.getString("status");
                facility = new facility(facilityId, name, type, capacity, slot, status);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return facility;
    }
    
    public void deleteFacility(int id) {
    String DELETE_FACILITY_SQL = "DELETE FROM facility WHERE facilityId = ?";
    try (Connection connection = getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(DELETE_FACILITY_SQL)) {
        preparedStatement.setInt(1, id);
        preparedStatement.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}


}
