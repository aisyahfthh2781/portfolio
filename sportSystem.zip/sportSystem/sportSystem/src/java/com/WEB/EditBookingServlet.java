package com.WEB;

import com.Dao.bookingDao;
import com.Model.bookingStudent;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EditBookingServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String sid = request.getParameter("bookingId");
        int bookingId = Integer.parseInt(sid);

        bookingStudent e = bookingDao.getUserById(bookingId);
        
        RequestDispatcher header = request.getRequestDispatcher("header.jsp");
        header.include(request, response);

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>Edit Booking</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; }");
        out.println("h1 { color: #333; }");
        out.println("form { max-width: 800px; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 30px; }");
        out.println("table { width: 100%; }");
        out.println("td { padding: 10px; }");
        out.println("input[type='text'], select { width: 100%; padding: 8px; margin: 5px 0; box-sizing: border-box; border: 1px solid #ccc; border-radius: 5px; }");
        out.println("input[type='submit'] { background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }");
        out.println("input[type='submit']:hover { background-color: #2329a8; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<h1>Update Booking</h1>");

        out.print("<form action='processEditBookingServlet' method='post'>");
        out.print("<table>");
        out.print("<tr><td></td><td><input type='hidden' name='bookingId' value='" + e.getBookingId() + "'/></td></tr>");
        out.print("<tr><td>Choose Facility:</td><td><input type='text' name='facility' readonly value='"+e.getFacility()+"'/></td></tr>");
        out.print("<tr><td>Date:</td><td><input type='date' name='date' value='" + e.getDate() + "'/></td></tr>");
        out.print("<tr><td>Time:</td><td>");
        out.print("<select name='time'>");
        out.print("<option " + (e.getTime().equals("8am - 10am") ? "selected" : "") + ">8am - 10am</option>");
        out.print("<option " + (e.getTime().equals("10am - 12pm") ? "selected" : "") + ">10am - 12pm</option>");
        out.print("<option " + (e.getTime().equals("3pm - 5pm") ? "selected" : "") + ">3pm - 5pm</option>");
        out.print("<option " + (e.getTime().equals("5pm - 7pm") ? "selected" : "") + ">5pm - 7pm</option>");
        out.print("</select>");
        out.print("</td></tr>");
        out.print("<tr><td>Purpose:</td><td><input type='text' name='purpose' value='" + e.getPurpose() + "'/></td></tr>");
        out.print("<tr><td>Category:</td><td><input type='text' name='category' value='" + e.getCategory() + "'/></td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save'></td></tr>");
        out.print("</table>");
        out.print("</form>");
        
        RequestDispatcher footer = request.getRequestDispatcher("footer.jsp");
        footer.include(request, response);

        out.println("</body>");
        out.println("</html>");
        
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Edit Booking Servlet";
    }
}
