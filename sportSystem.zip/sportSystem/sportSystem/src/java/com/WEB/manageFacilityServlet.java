/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.WEB;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Model.facility;

@WebServlet("/manageServlet")
public class manageFacilityServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private facilityDAO facilityDAO;

    public void init() {
        facilityDAO = new facilityDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String typeFacility = request.getParameter("typeFacility");
        List<facility> listFacility = facilityDAO.getFacilitiesByType(typeFacility);
        request.setAttribute("listFacility", listFacility);
        request.getRequestDispatcher("facilityList.jsp").forward(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<facility> listFacility = facilityDAO.getAllFacilities(); // Assuming you have this method
        request.setAttribute("listFacility", listFacility);
        request.getRequestDispatcher("facilityList.jsp").forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
