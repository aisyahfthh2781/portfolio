package com.WEB;

import com.Dao.bookingDao;
import com.Model.bookingStudent;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class processEditBookingServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            String sid = request.getParameter("bookingId");
            int bookingId = Integer.parseInt(sid);
            String facility = request.getParameter("facility");
            String date = request.getParameter("date");
            String time = request.getParameter("time");
            String purpose = request.getParameter("purpose");
            String category = request.getParameter("category");

            bookingStudent e = new bookingStudent();
            e.setBookingId(bookingId);
            e.setFacility(facility);
            e.setDate(date);
            e.setTime(time);
            e.setPurpose(purpose);
            e.setCategory(category);

            // Update the record in the database
            int status = bookingDao.update(e);
            if (status > 0) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Record saved successfully!');");
                out.println("location='ViewBookingServlet';");
                out.println("</script>");
            } else {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Sorry! Unable to update record');");
                out.println("location='EditBookingServlet';"); // Change 'editBookingPage' to your actual edit page URL
                out.println("</script>");
            }
        } catch (Exception ex) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Error: " + ex.getMessage() + "');");
            out.println("location='EditBookingServlet';"); // Change 'editBookingPage' to your actual edit page URL
            out.println("</script>");
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
