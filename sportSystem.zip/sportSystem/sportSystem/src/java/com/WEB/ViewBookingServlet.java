/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.WEB;

import com.Dao.bookingDao;
import com.Model.bookingStudent;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ADMINPC
 */
public class ViewBookingServlet extends HttpServlet {
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>Booking List</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px;background-color: #f8f9fa;font-size:14px;}");
        out.println("table { width: 80%; border-collapse: collapse; margin-bottom: 20px; }");
        out.println("table, th, td { border: 1px solid black; }");
        out.println("th, td { padding: 8px; text-align: left; }");
        out.println("th { background-color: #5d82e9; color: white; }");
        out.println(".button { padding: 10px 20px; margin-bottom: 20px; background-color: #007bff; color: white; text-decoration: none; border: none; border-radius: 5px; cursor: pointer; }");
        out.println(".button a { color: white; text-decoration: none; }");
        out.println(".button:hover { background-color: #2329a8; }");
        out.println(".action-button { padding: 5px 10px; border: none; border-radius: 3px; cursor: pointer; color: white; text-decoration: none; }");
        out.println(".edit-button { background-color: #28a745; }");
        out.println(".edit-button:hover { background-color: #218838; }");
        out.println(".delete-button { background-color: #dc3545; }");
        out.println(".delete-button:hover { background-color: #c82333; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        
        RequestDispatcher header = request.getRequestDispatcher("header.jsp");
        header.include(request, response);
        
        out.println("<button class='button'><a href='bkpage.jsp'>Add New Booking</a></button>");
        out.println("<h1>Booking List</h1>");

        List<bookingStudent> list = bookingDao.getAllUsers();

        if (list != null && !list.isEmpty()) {
            out.println("<table>");
            out.println("<tr><th>Bil</th><th>Facility</th><th>Date</th><th>Time</th><th>Purpose</th><th>Category</th><th>Action</th></tr>");

            for (bookingStudent e : list) {
                out.println("<tr>");
                out.println("<td>" + e.getBookingId() + "</td>");
                out.println("<td>" + e.getFacility() + "</td>");
                out.println("<td>" + e.getDate() + "</td>");
                out.println("<td>" + e.getTime() + "</td>");
                out.println("<td>" + e.getPurpose() + "</td>");
                out.println("<td>" + e.getCategory() + "</td>");
                out.println("<td><a href='EditBookingServlet?bookingId=" + e.getBookingId() + "' class='action-button edit-button'>Reschedule</a>");
                out.println("<a href='DeleteBookingServlet?bookingId=" + e.getBookingId() + "' class='action-button delete-button'>Cancel</a></td>");
                out.println("</tr>");
            }

            out.println("</table>");
        } else {
            out.println("<p>No bookings available.</p>");
        }
        out.println("</body>");
        
        RequestDispatcher footer = request.getRequestDispatcher("footer.jsp");
        footer.include(request, response);
        
        out.println("</html>");

        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "ViewBooking Servlet";
    }
}