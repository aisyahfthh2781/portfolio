package com.WEB;

import com.Model.facility;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/editServlet")
public class EditServlets extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private facilityDAO facilityDAO;

    public void init() {
        facilityDAO = new facilityDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        facility existingFacility = facilityDAO.getFacilityById(id);
        request.setAttribute("facility", existingFacility);
        request.getRequestDispatcher("EditFacility.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        int capacity = Integer.parseInt(request.getParameter("capacity"));
        int slot = Integer.parseInt(request.getParameter("slot"));
        String status = request.getParameter("status");

        facility facility = new facility(id, name, type, capacity, slot, status);
        facilityDAO.updateFacility(facility);
        response.sendRedirect("DashboardStaff.jsp");
    }
}
