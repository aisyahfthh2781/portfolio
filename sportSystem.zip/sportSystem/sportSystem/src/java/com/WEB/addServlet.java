package com.WEB;

import com.Model.facility;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addServlet")
public class addServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private facilityDAO facilityDAO;

    public void init() {
        facilityDAO = new facilityDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String type = request.getParameter("type");
        int capacity = Integer.parseInt(request.getParameter("capacity"));
        int slot = Integer.parseInt(request.getParameter("slot"));
        String status = request.getParameter("status");

        facility newFacility = new facility(name, type, capacity, slot, status);
        facilityDAO.addFacility(newFacility);
        response.sendRedirect("DashboardStaff.jsp");
    }
}
