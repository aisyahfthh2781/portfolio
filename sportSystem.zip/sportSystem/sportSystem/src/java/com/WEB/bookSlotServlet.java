package com.WEB;

import com.Dao.SlotDao;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/bookSlot")
public class bookSlotServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    int slotId = Integer.parseInt(request.getParameter("slotId"));
    int facilityId = Integer.parseInt(request.getParameter("facilityId"));
    int userId = Integer.parseInt(request.getParameter("userId"));

    try {
        Connection con = SlotDao.getConnection();
        String query = "INSERT INTO booking (slotId, facilityId, userId) VALUES (?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, slotId);
        ps.setInt(2, facilityId);
        ps.setInt(3, userId);
        ps.executeUpdate();
        con.close();
        
    } catch (Exception e) {
        e.printStackTrace();
    }

    response.sendRedirect("DashboardStudent.jsp?id="+userId);

}

}
