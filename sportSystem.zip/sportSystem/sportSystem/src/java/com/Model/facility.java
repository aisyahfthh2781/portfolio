package com.Model;

public class facility {
    private int facilityId;
    private String name;
    private String type;
    private int capacity;
    private int slot;
    private String status;

    public facility(int facilityId, String name, String type, int capacity, int slot, String status) {
        this.facilityId = facilityId;
        this.name = name;
        this.type = type;
        this.capacity = capacity;
        this.slot = slot;
        this.status = status;
    }
    
    
    public facility(String name, String type, int capacity, int slot, String status) {
        this.name = name;
        this.type = type;
        this.capacity = capacity;
        this.slot = slot;
        this.status = status;
    }

    // Getters and Setters
    public int getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(int facilityId) {
        this.facilityId = facilityId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
