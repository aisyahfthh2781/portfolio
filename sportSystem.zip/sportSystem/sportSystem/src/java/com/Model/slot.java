
package com.Model;


public class slot {
    private int slotId;
    private int facilityId;
    private int userId;
    private String date;
    private String time;
    private String purpose;
    private String category;
    
    public slot(){
        
    }
    
    public slot(int slotId, int facilityId,int userId, String date, String time, String purpose, String category){
        super();
        this.slotId = slotId;
        this.facilityId = facilityId;
        this.date = date;
        this.time = time;
        this.purpose = purpose;
        this.category = category;
    }

   
    public int getSlotId() {
        return slotId;
    }

  
    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    /**
     * @return the facilityId
     */
    public int getFacilityId() {
        return facilityId;
    }

    /**
     * @param facilityId the facilityId to set
     */
    public void setFacilityId(int facilityId) {
        this.facilityId = facilityId;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return the purpose
     */
    public String getPurpose() {
        return purpose;
    }

    /**
     * @param purpose the purpose to set
     */
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    
}
