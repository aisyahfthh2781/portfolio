package com.Model;


public class book {
    private int bookingId , facilityId , userId;
    
    
    public book(){
        
    }
    
    public book(int bookingId, int facilityId, int userId){
        super();
        this.bookingId = bookingId;
        this.facilityId = facilityId;
        this.userId = userId;
     
    }

   
    public int getBookingId() {
        return bookingId;
    }

 
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    
    public int getFacilityId() {
        return facilityId;
    }

  
    public void setFacilityId(int facilityId) {
        this.facilityId = facilityId;
    }

   
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

  
   
    
    
   
}
