import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SaveFeedback")
public class SaveFeedback extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        int userId = Integer.parseInt(request.getParameter("id"));

        if (userId == 0) {
            response.getWriter().println("User ID is not present in session.");
            return;
        }

        String message = request.getParameter("message");
        int rating = Integer.parseInt(request.getParameter("rating"));
        int facilityId = 0;
        String facilityName = request.getParameter("facilityId");
        switch (facilityName) {
            case "Futsal Court":
                facilityId = 1;
                break;
            case "Badminton Court":
                facilityId = 2;
                break;
            case "Swimming Pool":
                facilityId = 3;
                break;
            case "Volleyball Court":
                facilityId = 4;
                break;
            case "Gymnasium":
                facilityId = 5;
                break;
            case "Football Field":
                facilityId = 6;
                break;
            case "Basketball Court":
                facilityId = 7;
                break;
            default:
                // Handle invalid facility names or default case
                break;
        }

        if (message != null && !message.isEmpty()) {
            Feedback feedback = new Feedback();
            feedback.setUserId(userId);
            feedback.setMessage(message);
            feedback.setRating(rating);
            feedback.setFacilityId(facilityId); // Set facilityId

            System.out.println("Saving feedback: " + feedback); // Debugging statement

            int status = FeedbackDAO.save(feedback);

            String feedbackMessage;
            if (status > 0) {
                feedbackMessage = "Record saved successfully!";
                System.out.println("Feedback saved successfully."); // Debugging statement
            } else {
                feedbackMessage = "Sorry! unable to save record";
                System.out.println("Failed to save feedback."); // Debugging statement
            }

            request.setAttribute("message", feedbackMessage);
        }

        RequestDispatcher rd = request.getRequestDispatcher("feedback.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
