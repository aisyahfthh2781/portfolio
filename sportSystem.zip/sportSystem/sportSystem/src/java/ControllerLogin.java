
import com.Model.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ControllerLogin {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/sportsystem", "root", "admin");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static User login(User e) {
        Integer userId = null;
        String role = null;
        String name = null; // Add this line
        try {
            Connection con = ControllerLogin.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "select userId, role, name from users where username=? and password=?"); // Modify this line
            ps.setString(1, e.getUsername());
            ps.setString(2, e.getPassword());

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                userId = rs.getInt("userId");
                role = rs.getString("role");
                name = rs.getString("name"); // Add this line
                e.setUserId(userId);
                e.setRole(role);
                e.setName(name); // Add this line
            }

            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

    public static User loginStaffPSR(User e) {
        Integer userId = null;
        String role = null;
        String name = null; // Add this line
        try {
            Connection con = ControllerLogin.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "select userId, role, name from staff where username=? and password=?"); // Modify this line
            ps.setString(1, e.getUsername());
            ps.setString(2, e.getPassword());

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                userId = rs.getInt("userId");
                role = rs.getString("role");
                name = rs.getString("name"); // Add this line
                e.setUserId(userId);
                e.setRole(role);
                e.setName(name); // Add this line
            }

            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }
}
