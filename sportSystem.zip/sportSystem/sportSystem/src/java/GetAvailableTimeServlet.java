                                                                                                                                                                                                                     import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;

@WebServlet("/GetAvailableTimesServlet")
public class GetAvailableTimeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        // Retrieve parameters from request
        String facility = request.getParameter("facility");
        String date = request.getParameter("date");

        // Query database for available times
        List<String> availableTimes = fetchAvailableTimes(facility, date);

        // Convert availableTimes list to comma-separated string and send response
        String availableTimesStr = convertToCommaSeparatedString(availableTimes);
        out.print(availableTimesStr);
    }

    private List<String> fetchAvailableTimes(String facility, String date) {
        List<String> availableTimes = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Establish database connection (use your own connection setup)
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sportsystem", "root", "admin");

            // Query to fetch booked times
            String sql = "SELECT time FROM slot WHERE facilityid = ? AND date = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, facility);
            pstmt.setString(2, date);
            rs = pstmt.executeQuery();

            // Retrieve booked times
            List<String> bookedTimes = new ArrayList<>();
            while (rs.next()) {
                bookedTimes.add(rs.getString("time"));
            }

            // Define all possible times (customize based on your needs)
            String[] allTimes = {"8:00 a.m - 10:00 a.m", "10:00 a.m - 12:00 p.m", "2:00 p.m - 4:00 p.m", "4:00 p.m - 6:00 p.m"};

            // Add times that are not booked to availableTimes
            for (String time : allTimes) {
                if (!bookedTimes.contains(time)) {
                    availableTimes.add(time);
                }
            }

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return availableTimes;
    }

    private String convertToCommaSeparatedString(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i));
            if (i < list.size() - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }
}