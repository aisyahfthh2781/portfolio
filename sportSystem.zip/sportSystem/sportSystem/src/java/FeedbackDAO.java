
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FeedbackDAO {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/sportsystem", "root", "admin");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

     public static int save(Feedback e) {
        int status = 0;
        try (Connection con = FeedbackDAO.getConnection(); 
             PreparedStatement ps = con.prepareStatement("INSERT INTO feedback (userId, message, rating, facilityId) VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, e.getUserId());
            ps.setString(2, e.getMessage());
            ps.setInt(3, e.getRating());
            ps.setInt(4, e.getFacilityId()); // Set facilityId

            System.out.println("Executing query: " + ps); // Debugging statement

            status = ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return status;
    }

    public static int update(Feedback e) {
        int status = 0;
        try (Connection con = FeedbackDAO.getConnection(); 
             PreparedStatement ps = con.prepareStatement("UPDATE feedback SET feedback = ? WHERE feedbackId = ?")) {
            ps.setString(1, e.getMessage());
            ps.setInt(2, e.getFeedbackId());
            status = ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return status;
    }

    public static Feedback getFeedbackById(int feedbackId) {
        Feedback e = new Feedback();
        try (Connection con = FeedbackDAO.getConnection(); 
             PreparedStatement ps = con.prepareStatement("SELECT * FROM feedback WHERE feedbackId = ?")) {
            ps.setInt(1, feedbackId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                e.setFeedbackId(rs.getInt(1));
                e.setUserId(rs.getInt(2));
                e.setMessage(rs.getString(3));
                e.setRating(rs.getInt(4));
                e.setFacilityId(rs.getInt(5)); // Retrieve facilityId
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }
}
