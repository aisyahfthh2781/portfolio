import com.Model.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class loginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = new User(username, password, null);
        user = ControllerLogin.login(user);
        
        HttpSession session = request.getSession();
        session.setAttribute("userId", user.getUserId());
        session.setAttribute("role", user.getRole());
        session.setAttribute("name", user.getName());
        session.setAttribute("username", user.getUsername());

        String role = user.getRole();
        
        if (role != null) {
            if ("Student".equalsIgnoreCase(role)) {
                response.sendRedirect("DashboardStudent.jsp");
            } else if ("Staff".equalsIgnoreCase(role)) {
                response.sendRedirect("DashboardStudent.jsp");
            } else {
                response.getWriter().println("Invalid username or password");
            }
        } else {
            // Check if the user is a StaffPSR
            user = ControllerLogin.loginStaffPSR(user);
            role = user.getRole();
            if ("StaffPSR".equalsIgnoreCase(role)) {
                response.sendRedirect("DashboardStaff.jsp");
            } else {
                response.getWriter().println("Invalid username or password.");
            }
        }
    }
}
